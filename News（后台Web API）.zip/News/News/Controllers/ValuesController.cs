﻿using News.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Web.Http;

namespace News.Controllers
{
    public class ValuesController : ApiController
    {
       
        // 根据用户的传入参数，去数据库中的不同表中去查询新闻数据
        public object Get(String id)
        {
            SqlConnection con = new SqlConnection("Data Source=127.0.0.1;Initial Catalog=News;Integrated Security=False;User Id=sa;Password=P@ssw0rd");
            con.Open();
            string sql = "select * from " + id + ";";
            DataSet ds = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            adapter.Fill(ds);
            con.Close();
            return new{
                    code = 200,
                    msg = "success",
                    newslist = ds.Tables[0]
                };

        }

        // 新闻的详细信息
        [HttpGet]
        [Route("api/values/details/{id}")]
        public object Detail(String id)
        {
            SqlConnection con = new SqlConnection("Data Source=127.0.0.1;Initial Catalog=News;Integrated Security=False;User Id=sa;Password=P@ssw0rd");
            con.Open();

            string title = "";
            string source = "";
            string ptime = "";
             string body ="";
            string postid = "";

            ArrayList myArrayList = new ArrayList(5);
            
            string sql = "select * from imgArr where postid = '" + id + "';";
            SqlCommand cmd = new SqlCommand(sql, con); //缓冲区
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) {
                string refer = reader["ref"].ToString();
                string src = reader["src"].ToString();
                string alt = reader["alt"].ToString();
                string pixel = reader["pixel"].ToString();
                myArrayList.Add(new
                { 
                   refer = refer,
                   src = src,
                   alt = alt,
                   pixel = pixel
                });
            }
            reader.Close();
            sql = "select * from details where postid = '" + id + "';";
            cmd = new SqlCommand(sql, con); //缓冲区
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                postid = reader["postid"].ToString();
                title = reader["title"].ToString();
                source = reader["source"].ToString();
                ptime = reader["ptime"].ToString();
                body = reader["body"].ToString();
            }
            con.Close();

            return new {
                img = myArrayList,
                title = title,
                postid  = postid,
                source = source,
                ptime = ptime,
                body = body

            };
        }

        //在API部分对用户传入的密码进行二次加密
        public static string MD5Encode(string password)
        {
            var md5 = new MD5CryptoServiceProvider();
            string t2 = BitConverter.ToString(md5.ComputeHash(Encoding.Default.GetBytes(password)), 4, 8);
            t2 = t2.Replace("-", "");
            return t2;
        }

        //用户注册
        [HttpPost]
        [Route("api/values/regist")]
        public object regist([FromBody] User user)
        {
            if (user.username == null || user.password == null)
            {
                return new
                {
                    success = false,
                    errorMsg = "参数错误",
                    result = ""
                };
            }

            SqlConnection con = new SqlConnection("Data Source=127.0.0.1;Initial Catalog=News;Integrated Security=False;User Id=sa;Password=P@ssw0rd");
            con.Open();
            //查询数据库中是否已经有该用户
            string sql = "select * from users where username = '" + user.username + "';";
            DataSet ds = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            adapter.Fill(ds);
            if (ds.Tables[0].Rows.Count != 0)
            {
                return new
                {
                    success = false,
                    errorMsg = "该用户已存在",
                    result = ""
                };
            }
            //进行用户在数据库中的插入操作
            sql = "insert into users(username,password) values('" + user.username + "','" + MD5Encode(user.password) + "');";
            SqlCommand cmd = new SqlCommand(sql, con);
            int res = cmd.ExecuteNonQuery(); //会返回数据库受影响的行数

            if (res > 0)
            {
                //如果插入成功，就返回用户的ID值
                sql = "select * from users where username = '" + user.username + "';";
                cmd = new SqlCommand(sql, con); //缓冲区
                SqlDataReader reader = cmd.ExecuteReader();
                string userId = "";
                while (reader.Read())
                {
                    userId = reader["id"].ToString();
                }
                con.Close();
                return new
                {
                    success = true,
                    errorMsg = "",
                    result = new
                    {
                        id = Convert.ToInt32(userId),
                        userName = user.username
                    }
                };
            }
            else
            {
                con.Close();
                return new
                {
                    success = false,
                    errorMsg = "参数错误",
                    result = ""
                };
            }

        }

        //用户登录
        [HttpPost]
        [Route("api/values/login")]
        public object login([FromBody] User user)
        {
            if (user.username == null || user.password == null)
            {
                return new
                {
                    success = false,
                    errorMsg = "参数错误",
                    result = ""
                };
            }
            SqlConnection con = new SqlConnection("Data Source=127.0.0.1;Initial Catalog=News;Integrated Security=False;User Id=sa;Password=P@ssw0rd");
            con.Open();
            string sql = "select * from users where username = '" + user.username + "' and password = '" + MD5Encode(user.password) + "';";
            DataSet ds = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            adapter.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                con.Close();
                return new
                {
                    success = false,
                    errorMsg = "用户名或密码错误!",
                    result = ""
                };
            }
            else
            {
                DataRow dr = ds.Tables[0].Rows[0];
                string userId = dr["id"].ToString();
                string userName = dr["username"].ToString();
                con.Close();
                return new
                {
                    success = true,
                    errorMsg = "",
                    result = new
                    {
                        id = userId,
                        userName = userName
                    }
                };
            }

        }

        //用户密码修改
        [HttpPost]
        [Route("api/values/update")]
        public object update([FromBody] User user)
        {
            if (user.username == null || user.password == null)
            {
                return new
                {
                    success = false,
                    errorMsg = "参数错误",
                    result = ""
                };
            }

            SqlConnection con = new SqlConnection("Data Source=127.0.0.1;Initial Catalog=News;Integrated Security=False;User Id=sa;Password=P@ssw0rd");
            con.Open();
            //查询数据库中是否已经有该用户
            string sql = "select * from users where username = '" + user.username + "';";
            DataSet ds = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            adapter.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                return new
                {
                    success = false,
                    errorMsg = "用户不存在",
                    result = ""
                };
            }
            //进行用户在数据库中的更新操作
            sql = "update users set password = '" + MD5Encode(user.password) + "' where username = '" + user.username + "';";
            SqlCommand cmd = new SqlCommand(sql, con);
            int res = cmd.ExecuteNonQuery(); //会返回数据库受影响的行数

            if (res > 0)
            {
                //如果插入成功，就返回用户的ID值
                sql = "select * from users where username = '" + user.username + "';";
                cmd = new SqlCommand(sql, con); //缓冲区
                SqlDataReader reader = cmd.ExecuteReader();
                string userId = "";
                while (reader.Read())
                {
                    userId = reader["id"].ToString();
                }
                con.Close();
                return new
                {
                    success = true,
                    errorMsg = "",
                    result = new
                    {
                        id = userId
                    }
                };
            }
            else
            {
                con.Close();
                return new
                {
                    success = false,
                    errorMsg = "参数错误",
                    result = ""
                };
            }

        }


    }
}
