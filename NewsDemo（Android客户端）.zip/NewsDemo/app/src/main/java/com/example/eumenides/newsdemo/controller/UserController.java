package com.example.eumenides.newsdemo.controller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.HashMap;

import com.alibaba.fastjson.JSON;
import com.example.eumenides.newsdemo.bean.RResult;
import com.example.eumenides.newsdemo.utils.Constant;
import com.example.eumenides.newsdemo.utils.IdiyMessage;
import com.example.eumenides.newsdemo.utils.NetworkUtil;

//这是用于登录和注册
public class UserController extends BaseController {

    @Override
    protected void handleMessage(int action, Object... values) {
        switch (action) {
            case IdiyMessage.LOGIN_ACTION:
                RResult rResult = loginOrRegist(Constant.LOGIN_URL,
                        (String) values[0], (String) values[1]);
                mListener.onModeChanged(IdiyMessage.LOGIN_ACTION_RESULT, rResult);
                break;
            case IdiyMessage.REGIST_ACTION:
                RResult loginOrRegist = loginOrRegist(Constant.REGIST_URL, (String) values[0],
                        (String) values[1]);
                mListener.onModeChanged(IdiyMessage.REGIST_ACTION_RESULT, loginOrRegist);
                break;
            case IdiyMessage.UPDATE_ACTION:
                RResult editMyInfo = loginOrRegist(Constant.UPDATE_URL, (String) values[0],
                        (String) values[1]);
                mListener.onModeChanged(IdiyMessage.UPDATE_ACTION_RESULT, editMyInfo);
                break;
        }
    }

    private RResult loginOrRegist(String url, String name, String pwd) {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("username", name);
        params.put("password", pwd);
        String jsonStr = NetworkUtil.doPost(url, params);
        return JSON.parseObject(jsonStr, RResult.class);
    }

}
