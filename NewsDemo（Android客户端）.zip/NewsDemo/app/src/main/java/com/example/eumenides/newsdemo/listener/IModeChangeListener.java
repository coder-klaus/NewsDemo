package com.example.eumenides.newsdemo.listener;

public interface IModeChangeListener {

	public void onModeChanged(int action, Object... values);
	
}
