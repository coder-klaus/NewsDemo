package com.example.eumenides.newsdemo.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.adapter.NewAdapter;
import com.example.eumenides.newsdemo.bean.FragmentInfo;
import com.example.eumenides.newsdemo.news_inner.FinanceFragment;
import com.example.eumenides.newsdemo.news_inner.FunFragment;
import com.example.eumenides.newsdemo.news_inner.HotFragment;
import com.example.eumenides.newsdemo.news_inner.SocialFragment;
import com.example.eumenides.newsdemo.news_inner.SportFragment;
import com.example.eumenides.newsdemo.news_inner.TechFragment;
import com.example.eumenides.newsdemo.news_inner.MilitaryFragment;
import com.example.eumenides.newsdemo.news_inner.TravelFragment;
import com.ogaclejapan.smarttablayout.SmartTabLayout;

import java.util.ArrayList;

/**
 * 这是新闻中心的fragement
 */

public class NewsFragment extends Fragment {
    ArrayList<FragmentInfo> pages;
    NewAdapter newAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //inflater.inflate 类似于findViewByid()
        View view = inflater.inflate(R.layout.fragment_news, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        pages = new ArrayList<>();

        FrameLayout layout = (FrameLayout) getActivity().findViewById(R.id.tabs);
        layout.addView(View.inflate(getActivity(), R.layout.include_tab, null));

        SmartTabLayout smartTabLayout = (SmartTabLayout) getActivity().findViewById(R.id.smart_tab);
        ViewPager viewPager = (ViewPager) getActivity().findViewById(R.id.viewpager);

        //这是所有新闻组件的模块数组
        Fragment[] fragments = { new HotFragment(),new SocialFragment(),new FunFragment(),
                new MilitaryFragment(),new SportFragment(),new TechFragment(),new FinanceFragment(),new TravelFragment()};
        String[] titles = getResources().getStringArray(R.array.news_titles);
        for (int i = 0; i < titles.length; i++) {
            FragmentInfo info;
            info = new FragmentInfo(fragments[i], titles[i]);

            pages.add(info);
        }
        newAdapter = new NewAdapter(getFragmentManager(), pages);
        viewPager.setAdapter(newAdapter);

        //数据的绑定
        smartTabLayout.setViewPager(viewPager);

    }
}
