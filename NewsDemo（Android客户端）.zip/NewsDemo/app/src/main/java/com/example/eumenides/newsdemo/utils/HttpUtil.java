package com.example.eumenides.newsdemo.utils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 这是从网络中获取数据的工具类
 */
public class HttpUtil {
    static HttpUtil util;
    static OkHttpClient client;


    private HttpUtil(){
        client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    //单例的方法
    public static HttpUtil getInstance(){
        if(util==null){
            synchronized (HttpUtil.class){ //里面的class为类锁
               if(util==null){
                   util = new HttpUtil();
               }
            }
        }
        return  util;
    }

    public void getDate(String url, final HttpRespon respon){
        Request request = new Request.Builder()
                .url(url)
                .build();

        //开启一个异步请求
        client.newCall(request).enqueue(new Callback() {

            //请求失败
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                respon.onError("连接服务器失败");
            }

            //有响应
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    //请求失败
                    respon.onError("连接服务器失败");
                    return;
                }
                //200 -> json

                //获取到接口的数据
                String date = response.body().string();

                respon.parse(date);
            }
        });
    }

}
