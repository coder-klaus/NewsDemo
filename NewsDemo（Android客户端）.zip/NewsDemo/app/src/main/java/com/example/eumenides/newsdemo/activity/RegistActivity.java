package com.example.eumenides.newsdemo.activity;

import android.os.Bundle;
import android.os.Message;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.bean.RResult;
import com.example.eumenides.newsdemo.controller.UserController;
import com.example.eumenides.newsdemo.utils.IdiyMessage;
import com.example.eumenides.newsdemo.utils.MD5Helper;

public class RegistActivity extends BaseActivity  {

	private EditText mNameEt;
	private EditText mPwdEt;
	private EditText mSurePwdEt;
	private CheckBox checkBox1;
	
	@Override
	protected void handlerMessage(Message msg) {
		switch (msg.what) {
			case IdiyMessage.REGIST_ACTION_RESULT:
				handleRegistResult((RResult) msg.obj);
				break;
		}
	}

	private void handleRegistResult(RResult resultBean) {
		//如果注册成功，跳转到登录界面，如果注册失败，否则就提示错误
		tip(resultBean.isSuccess()?"注册新用户成功":resultBean.getErrorMsg());
		if (resultBean.isSuccess()) {
			//如果登录成功以后，就只有
			finish();
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_regist);
		initController();
		initUI();

		checkBox1=(CheckBox) findViewById(R.id.checkBox1);

		checkBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked){
					//如果选中，显示密码
					mPwdEt.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
					mSurePwdEt.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
				}else{
					//否则隐藏密码
					mPwdEt.setTransformationMethod(PasswordTransformationMethod.getInstance());
					mSurePwdEt.setTransformationMethod(PasswordTransformationMethod.getInstance());
				}
			}
		});
	}

	@Override
	protected void initController() {
		mController = new UserController();
		//告诉程序，数据已经加载完毕
		mController.setIModeChangeListener(this);
	}

	@Override
	protected void initUI() {
		mNameEt = (EditText) findViewById(R.id.username_et);
		mPwdEt = (EditText) findViewById(R.id.pwd_et);
		mSurePwdEt = (EditText) findViewById(R.id.surepwd_et);
	}

	public void registClick(View v) {
		String name = mNameEt.getText().toString();
		String pwd = MD5Helper.md5(mPwdEt.getText().toString());
		String surePwd = MD5Helper.md5(mSurePwdEt.getText().toString());
		if (ifValueWasEmpty(name, pwd, surePwd)) {
			tip("信息填写不完全!");
			return;
		}
		if (!pwd.equals(surePwd)) {
			tip("两次输入密码不一致");
			return;
		}

		//进行用户的注册
		mController.sendAsyncMessage(IdiyMessage.REGIST_ACTION, name, pwd);
	}

}
