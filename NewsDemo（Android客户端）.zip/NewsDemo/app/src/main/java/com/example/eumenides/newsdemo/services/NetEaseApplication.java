package com.example.eumenides.newsdemo.services;

import android.app.Application;
import android.os.Environment;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.io.File;

/**
 * 当整个应用被创建的时候，该类会被调用
 * 该类的作用是在打开应用的时候，初始化ImageLoaderConfiguration
 * 以便于加载图片
 */

public class NetEaseApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();


        File sd = Environment.getExternalStorageDirectory();
        File image_loader_cache= new File(sd,"news");
        if(!image_loader_cache.exists()){
            image_loader_cache.mkdirs();
        }

        //全局显示的设置类
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(this).discCache(new UnlimitedDiskCache(image_loader_cache))
                                                .diskCacheFileNameGenerator(new Md5FileNameGenerator()).build();

        ImageLoader.getInstance().init(config);

    }
}
