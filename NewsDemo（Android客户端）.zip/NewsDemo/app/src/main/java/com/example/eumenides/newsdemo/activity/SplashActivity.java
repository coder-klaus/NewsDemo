package com.example.eumenides.newsdemo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.utils.ActivityUtil;

//这是开始欢迎页面的动画具体实现类
public class SplashActivity extends Activity {

    //定义欢迎页面的实体
    private RelativeLayout activity_welcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //实例化欢迎页面
        activity_welcome = (RelativeLayout) findViewById(R.id.activity_welcome);

        //渐变动画的实现代码
        AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);

        //缩放动画的具体实现代码
        ScaleAnimation scaleAnimation = new ScaleAnimation(0, 1, 0, 1, ScaleAnimation.RELATIVE_TO_SELF, 0.5f, ScaleAnimation.RELATIVE_TO_SELF, 0.5f);

        //设置旋转动画
        RotateAnimation rotateAnimation = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);

        //在容器中依次添加 渐变动画，缩放动画 和 旋转动画
        //3个动画是同时播放的，所以他们之间没有先后顺序
        AnimationSet animationSet = new AnimationSet(false);
        animationSet.addAnimation(rotateAnimation);
        animationSet.addAnimation(alphaAnimation);
        animationSet.addAnimation(scaleAnimation);

        //设置渐变动画的持续播放时间为1300ms
        animationSet.setDuration(2000);
        //是动画停留在播放后的状态
        rotateAnimation.setFillAfter(true);

        //启动动画
        activity_welcome.startAnimation(animationSet);

        //只有动画其自己知道动画执行完毕，所以为动画执行监听
        animationSet.setAnimationListener(new MyAnimationListener());
    }

    //定义一个实现动画监听器接口的具体类
    class MyAnimationListener implements Animation.AnimationListener {

        @Override
        public void onAnimationStart(Animation animation) {

        }

        @Override
        public void onAnimationEnd(Animation animation) {
            //两秒后进入主页面
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    ActivityUtil.start(SplashActivity.this,LoginActivity.class, true);
                    //关闭当前页面
                    finish();
                }
            }, 2000);
        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    }
}
