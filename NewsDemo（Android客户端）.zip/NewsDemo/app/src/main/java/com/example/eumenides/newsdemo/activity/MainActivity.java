package com.example.eumenides.newsdemo.activity;

import android.content.Context;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.fragment.NewsFragment;
import com.example.eumenides.newsdemo.fragment.SettingFragment;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //创建并绑定fragemnet容器
        FragmentTabHost tabHost = (FragmentTabHost) findViewById(R.id.tab_Host);

        //获取所有标签页的标题
        String[] titles = getResources().getStringArray(R.array.tab_title);
        //所有的选项卡中的icon的选择器
        int[] icons = new int[]{R.drawable.news_selector, R.drawable.mine_selector};

        //所有的碎片类
        Class[] classes = new Class[]{NewsFragment.class, SettingFragment.class};

        tabHost.setup(this, getSupportFragmentManager(), android.R.id.content);

        for (int i = 0; i < titles.length; i++) {
            //为每个Fragemnet创建选项卡
            TabHost.TabSpec tmp = tabHost.newTabSpec("" + i);
            tmp.setIndicator(getView(this, titles, icons, i));

            //为每个选项卡设置对应的fragement容器中的具体内容
            tabHost.addTab(tmp, classes[i], null);
        }

        //监听FragmentTabHost的切换
        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                Log.i("News", "tabId=" + tabId);
            }
        });


    }

    /**
     * 该方法用来设置标签的内容和图标
     *
     * @param context
     * @param titles
     * @param icons
     * @param index
     * @return
     */
    public View getView(Context context, String[] titles, int[] icons, int index) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View title_view = inflater.inflate(R.layout.item_title, null);
        TextView title = (TextView) title_view.findViewById(R.id.title);
        ImageView icon = (ImageView) title_view.findViewById(R.id.icon);
        // 设置标签的内容
        title.setText(titles[index]);
        icon.setImageResource(icons[index]);
        return title_view;
    }

}
