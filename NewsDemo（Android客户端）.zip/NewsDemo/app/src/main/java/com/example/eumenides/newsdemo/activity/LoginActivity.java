package com.example.eumenides.newsdemo.activity;

import android.os.Bundle;
import android.os.Message;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.bean.RResult;
import com.example.eumenides.newsdemo.controller.UserController;
import com.example.eumenides.newsdemo.utils.ActivityUtil;
import com.example.eumenides.newsdemo.utils.IdiyMessage;
import com.example.eumenides.newsdemo.utils.MD5Helper;
import com.example.eumenides.newsdemo.utils.SharedPreUtil;


public class LoginActivity extends BaseActivity {

    private EditText mNameEt;
    private EditText mPwdEt;

    private CheckBox showPwd;

    @Override
    protected void handlerMessage(Message msg) {
        switch (msg.what) {
            case IdiyMessage.LOGIN_ACTION_RESULT:
                handleLoginResult(msg);
                break;
        }
    }

    private void handleLoginResult(Message msg) {
        RResult rResult = (RResult) msg.obj;
        if (rResult.isSuccess()) {

            SharedPreUtil.setParam(LoginActivity.this, SharedPreUtil.IS_LOGIN, true);
            SharedPreUtil.setParam(LoginActivity.this, SharedPreUtil.LOGIN_DATA, mNameEt.getText().toString());
            SharedPreUtil.setParam(LoginActivity.this, SharedPreUtil.LOGIN_PWD, mPwdEt.getText().toString());

            ActivityUtil.start(this, MainActivity.class, true);

        } else {
            tip("登录失败:" + rResult.getErrorMsg());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initController();
        initUI();

        showPwd = (CheckBox) findViewById(R.id.showPwd);

        showPwd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // TODO Auto-generated method stub
                if (isChecked) {
                    //如果选中，显示密码
                    mPwdEt.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    //否则隐藏密码
                    mPwdEt.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

            }
        });
    }

    public void loginClick(View v) {

        String name = mNameEt.getText().toString();
        String pwd = MD5Helper.md5(mPwdEt.getText().toString());
        if (ifValueWasEmpty(name, pwd)) {
            tip("请输入用户名和密码");
            return;
        }

        //发送一个网络请求，去请求网络数据
        mController.sendAsyncMessage(IdiyMessage.LOGIN_ACTION, name, pwd);
    }

    public void registClick(View v) {

        //不需要关闭登录页面，以便于返回的时候可以直接跳转到登录页面
        ActivityUtil.start(this, RegistActivity.class, false);
    }


    @Override
    protected void initController() {
        mController = new UserController();
        mController.setIModeChangeListener(this);
    }

    @Override
    protected void initUI() {
        mNameEt = (EditText) findViewById(R.id.name);
        mPwdEt = (EditText) findViewById(R.id.pwd);

        //从sharedPreference中获取用户所存储的用户信息
        String name = (String) SharedPreUtil.getParam(LoginActivity.this, SharedPreUtil.LOGIN_DATA, "");
        String pwd = (String) SharedPreUtil.getParam(LoginActivity.this, SharedPreUtil.LOGIN_PWD, "");

        // 设置用户名（在注销登录和退出应用后，再次登录的时候使用）
        mNameEt.setText(name);

        //判断用户是否有保存的用户信息，如果有则直接登录，如果没有，则进入登录界面
        if (name.length() > 0 && pwd.length() > 0) {
            //不需要关闭登录页面，以便于返回的时候可以直接跳转到登录页面
            ActivityUtil.start(this, MainActivity.class, true);
        }
    }
}
