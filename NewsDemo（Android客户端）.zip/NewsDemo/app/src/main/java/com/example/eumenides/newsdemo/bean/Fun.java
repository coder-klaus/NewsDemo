package com.example.eumenides.newsdemo.bean;

import java.util.List;

/**
 * 这是 新闻模块的javabean类
 */

public class Fun {
    List<FunDetail>  newslist;

    public List<FunDetail> getNewslist() {
        return newslist;
    }

    public void setNewslist(List<FunDetail> newslist) {
        this.newslist = newslist;
    }

    @Override
    public String toString() {
        return "Fun{" +
                "newslist=" + newslist +
                '}';
    }
}
