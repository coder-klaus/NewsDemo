package com.example.eumenides.newsdemo.utils;

/**
 * 这是app中所以使用到的常量类
 */

public class Constant {

    public static final String BASE_URL = "http://10.0.2.2:40815"; //Web Api的根目录


    //新闻各个fragment的api地址
    public static final String HOT_URL =  BASE_URL + "/api/values/hot"; //新闻头条
    public static final String Social_URL =  BASE_URL + "/api/values/social"; //社会新闻
    public static final String FUN_URL =  BASE_URL + "/api/values/entertainment"; //娱乐模块
    public static final String MILITATY_URL =  BASE_URL + "/api/values/Military"; //军事模块
    public static final String SPORT_URL =  BASE_URL + "/api/values/Sport"; //体育中心
    public static final String TECH_URL =  BASE_URL + "/api/values/Technology"; //科技中心
    public static final String Finance_URL =  BASE_URL + "/api/values/Finance"; //财经新闻
    public static final String Travel_URL =  BASE_URL + "/api/values/Travel"; //旅游资讯

    //登录,注册和修改密码的接口
    public static final String LOGIN_URL = BASE_URL + "/api/values/login"; //登录的接口
    public static final String REGIST_URL = BASE_URL + "/api/values/regist"; //注册的接口
    public static final String UPDATE_URL = BASE_URL + "/api/values/update"; //修改密码的接口


    //详情页面的api接口
    public static final String DETAIL_URL = BASE_URL + "/api/values/details/";

    //通过字符串拼接的方式，获取到所有的新闻的详情页面
    public static String getDetailUrl(String postid){
        String result;
        result = DETAIL_URL + postid;
        return  result;
    }
}
