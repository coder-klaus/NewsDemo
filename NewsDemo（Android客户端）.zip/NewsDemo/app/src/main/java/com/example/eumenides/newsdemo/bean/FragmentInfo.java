package com.example.eumenides.newsdemo.bean;

import android.support.v4.app.Fragment;

/**
 * 这是新闻详情页面顶部滑动条每个标签块的javabean类
 */

public class FragmentInfo {
    Fragment fragment;
    String title;

    public FragmentInfo(Fragment fragment, String title) {
        this.fragment = fragment;
        this.title = title;
    }

    public Fragment getFragment() {
        return fragment;
    }

    public void setFragment(Fragment fragment) {
        this.fragment = fragment;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "FragmentInfo{" +
                "fragment=" + fragment +
                ", title='" + title + '\'' +
                '}';
    }
}
