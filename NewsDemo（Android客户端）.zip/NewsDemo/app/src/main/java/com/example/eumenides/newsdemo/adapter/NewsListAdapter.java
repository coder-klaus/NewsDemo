package com.example.eumenides.newsdemo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.bean.FunDetail;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;

/**
 * 这是 新闻列表 的适配器
 */

public class NewsListAdapter extends BaseAdapter {
    ArrayList<FunDetail> funDetail;
    LayoutInflater inflater;

    //这个类的显示的配置类
    DisplayImageOptions options;

    public NewsListAdapter(ArrayList<FunDetail> funDetail, Context context) {
        this.funDetail = funDetail;
        this.inflater = LayoutInflater.from(context);
        //建造者模式 -> 创建一个复杂的对象
        options = new DisplayImageOptions.Builder()
                .showImageOnLoading(R.drawable.image_error) //默认图标
                .cacheInMemory(true) //在内存中缓存图片
                .displayer(new FadeInBitmapDisplayer(500)) //设置图片显示的渐变时间为0.5s
                .build();
    }

    @Override
    public int getCount() {
        return funDetail.size();
    }

    @Override
    public Object getItem(int position) {
        return funDetail.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        NewsListAdapter.ViewHoder hoder;
        FunDetail detail = funDetail.get(i);

        if(convertView == null){
            convertView = inflater.inflate(R.layout.items_hot,null);

            hoder = new NewsListAdapter.ViewHoder();
            hoder.icon = (ImageView) convertView.findViewById(R.id.img);
            hoder.title = (TextView) convertView.findViewById(R.id.title);
            hoder.source = (TextView) convertView.findViewById(R.id.source);

            convertView.setTag(hoder);
        }else{
            hoder = (NewsListAdapter.ViewHoder) convertView.getTag();
        }
        //初始化
        initViews(hoder, detail);
        return  convertView;
    }

    //初始化
    public void initViews(NewsListAdapter.ViewHoder hoder, FunDetail detail){
        hoder.title.setText(detail.getTitle());
        hoder.source.setText(detail.getDescription());
        //显示图片的方法
        ImageLoader.getInstance().displayImage(detail.getPicUrl(), hoder.icon, options, new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String s, View view) { //图片开始加载的时候
                Log.i("News","onLoadingStarted");
            }

            @Override
            public void onLoadingFailed(String s, View view, FailReason failReason) {//图片加载失败
                Log.i("News","onLoadingFailed");
            }

            @Override
            public void onLoadingComplete(String s, View view, Bitmap bitmap) {//图片加载完成时候
                Log.i("News","onLoadingComplete");
            }

            @Override
            public void onLoadingCancelled(String s, View view) { //页面退出的时候
                Log.i("News","onLoadingCancelled");
            }
        });

    }

    //获取新闻的数据
    public FunDetail getDateByIndex(int index){
        FunDetail detail = funDetail.get(index);
        return detail;
    }

    class ViewHoder {
        ImageView icon;
        TextView title;
        TextView source;
    }
}
