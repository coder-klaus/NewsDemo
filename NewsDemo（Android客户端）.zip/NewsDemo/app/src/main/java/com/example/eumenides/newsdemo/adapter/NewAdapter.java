package com.example.eumenides.newsdemo.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.eumenides.newsdemo.bean.FragmentInfo;

import java.util.ArrayList;

/**
 * 这是用于显示新闻页顶部详情页面的滑动条效果的适配器
 */

public class NewAdapter extends FragmentStatePagerAdapter {
    ArrayList<FragmentInfo> fragments;

    public NewAdapter(FragmentManager fm, ArrayList<FragmentInfo> fragments) {
        super(fm);
        this.fragments = fragments;
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position).getFragment();
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return fragments.get(position).getTitle();
    }
}
