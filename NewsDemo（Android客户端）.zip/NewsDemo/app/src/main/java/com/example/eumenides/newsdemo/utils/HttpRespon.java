package com.example.eumenides.newsdemo.utils;

import android.text.TextUtils;

/**
 * 这是一个用于回调的类，用于返回HTTP请求是成功还是失败
 */
public abstract class HttpRespon<T> {
    //http返回的类型的泛型
    Class<T> t;

    //通过构造函数获取所需要的类型
    public HttpRespon(Class<T> t){
        this.t = t;
    }

    //失败->调用者->失败的原因
    public abstract void  onError(String msg);
    //成功->返回我需要的类型
    public abstract void  onSuccess(T t);


    public void parse(String json){
       if(TextUtils.isEmpty(json)){
           //请求失败
           onError("网络失败");
           return;
       }


        //如果我需要的是string类型的数据（原始的json格式数据），就直接返回string类型数据，不需要再进行json的数据转换
        if(t == String.class){
            onSuccess((T)json);
            return;
        }

        //尝试转化json->需要的类型
        T result = JsonUtil.parseJson(json,t);

        //转化成功
        if(result!=null){
            onSuccess(result);
        }else{
            onError("json解析失败");
        }
    }
}
