package com.example.eumenides.newsdemo.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.example.eumenides.newsdemo.activity.BaseActivity;

public class ActivityUtil {

	/**
	 * 进行activity和activity之间的跳转
	 * @param c 当前上下文，即当前的页面
	 * @param clazz 需要跳转到的页面
	 * @param ifFinishSelf 是否需要关闭当前页面
     */
	public static void start(Context c, Class<?> clazz, boolean ifFinishSelf){
		Intent intent=new Intent(c,clazz);
		c.startActivity(intent);
		if (ifFinishSelf) {
			((Activity)c).finish();
		}
	}
	
}
