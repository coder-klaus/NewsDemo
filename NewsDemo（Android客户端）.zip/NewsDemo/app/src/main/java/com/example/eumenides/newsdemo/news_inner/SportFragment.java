package com.example.eumenides.newsdemo.news_inner;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.activity.DetailActivity;
import com.example.eumenides.newsdemo.adapter.NewsListAdapter;
import com.example.eumenides.newsdemo.bean.Fun;
import com.example.eumenides.newsdemo.bean.FunDetail;
import com.example.eumenides.newsdemo.utils.Constant;
import com.example.eumenides.newsdemo.utils.HttpRespon;
import com.example.eumenides.newsdemo.utils.HttpUtil;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;


/**
 * 这是体育中心页面
 */

public class SportFragment extends Fragment {
    ListView listView;
    ArrayList<FunDetail> funDetails;
    ArrayList<View> views;

    MyHandler handler;
    //因为JSON格式相同，所以此处就采用娱乐模块的适配器
    NewsListAdapter adapter;

    private final static int INIT_SUCCESS = 0;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_newslist, container, false);
        listView = (ListView) view.findViewById(R.id.listView);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        funDetails = new ArrayList<>();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent();
                intent.setClass(getActivity(), DetailActivity.class);
                FunDetail detail = adapter.getDateByIndex(i);
                intent.putExtra(DetailActivity.POSTID,detail.getPostid());
                startActivity(intent);
                //实现从左到右的一个滑动效果
                getActivity().overridePendingTransition(R.anim.activity_in,R.anim.activity_out);
            }
        });

        handler = new MyHandler(this);

        HttpUtil util = HttpUtil.getInstance();
        util.getDate(Constant.SPORT_URL, new HttpRespon<Fun>(Fun.class) {
            @Override
            public void onError(String msg) {

            }

            @Override
            public void onSuccess(Fun fun) {
                if (fun != null && fun.getNewslist() != null) {
                    List<FunDetail> details = fun.getNewslist();

                    //加载listview中的数据
                    funDetails.addAll(details);

                    handler.sendEmptyMessage(INIT_SUCCESS);

                }
            }
        });
    }
    //处理listView的数据
    public void initDate() {
        adapter = new NewsListAdapter(funDetails, getActivity());
        listView.setAdapter(adapter);
    }

    static class MyHandler extends Handler{
        WeakReference<SportFragment> weak_fragment;

        public MyHandler(SportFragment fragment) {
            this.weak_fragment = new WeakReference(fragment);
        }

        @Override
        public void handleMessage(Message msg) {
            SportFragment fun = weak_fragment.get();
            if (fun == null) {
                return;
            }
            switch (msg.what) {
                case INIT_SUCCESS:
                    fun.initDate();
                    break;

                default:
                    break;
            }

        }
    }
}
