package com.example.eumenides.newsdemo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.bean.DetailWeb;
import com.example.eumenides.newsdemo.bean.DetailWebImage;
import com.example.eumenides.newsdemo.utils.Constant;
import com.example.eumenides.newsdemo.utils.HttpRespon;
import com.example.eumenides.newsdemo.utils.HttpUtil;
import com.example.eumenides.newsdemo.utils.JsonUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * 这是新闻详情页面的activity
 */

public class DetailActivity extends Activity {
    public static final String POSTID = "postid";

    String post_id;
    String body;
    MyHandler mHandler;
    WebView mWebView;

    private static int INITSUCCESS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);

        mHandler = new MyHandler(this);
        post_id = getIntent().getStringExtra(POSTID);

        Log.i("detail", "post_id =" + post_id);

        HttpUtil util = HttpUtil.getInstance();
        String url = Constant.getDetailUrl(post_id);

        Log.i("URL", url);

        ImageView back = (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();

                intent.setClass(DetailActivity.this, MainActivity.class);

                startActivity(intent);
                //实现从左到右的一个滑动效果
                finish();
                overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_from_left);
            }
        });


        util.getDate(url, new HttpRespon<String>(String.class) {
            @Override
            public void onError(String msg) {
                Log.i("error", msg);
            }

            @Override
            public void onSuccess(String json) {
                try {
                    Log.i("json", json);
                    JSONObject js = new JSONObject(json);

                    DetailWeb web = JsonUtil.parseJson(js.toString(), DetailWeb.class);
                    Log.i("web", web.toString());
                    if (web != null) {
                        body = web.getBody();
                        List<DetailWebImage> images = web.getImg();
                        for (int i = 0; i < images.size(); i++) {
                            String src = images.get(i).getSrc();
                            String imageTag = "<img src = '" + src + "'/>";
                            String tag = "<!--IMG#" + i + "-->";
                            body = body.replace(tag, imageTag);
                        }

                        String titleHTML = "<p><span style='font-size:18px;'><strong>" + web.getTitle() + "</strong></span></p>";// 标题

                        titleHTML = titleHTML + "<p><span style='color:#666666;'>" + web.getSource() + "&nbsp&nbsp" + web.getPtime() + "</span></p>";//来源与时间

                        body = titleHTML + body;
                        //使用CSS和JS使用图片大小自适应于手机屏幕同时可以进行点击显示原始图
                        body = "<html><head><style>img{width:100%}</style></head><body>" + body + "</body></html>";

                        mHandler.sendEmptyMessage(INITSUCCESS);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void initWebview() {
        mWebView.loadDataWithBaseURL(null, body, "text/html", "utf-8", null);
    }

    static class MyHandler extends Handler {
        //定义弱引用，便于回收，防止内存泄露
        WeakReference<DetailActivity> activity;

        public MyHandler(DetailActivity dActivity) {
            this.activity = new WeakReference(dActivity);
        }

        @Override
        public void handleMessage(Message msg) {
            DetailActivity detailActivity = activity.get();
            //如果详情页面中没有数据
            if (null == detailActivity) {
                return;
            }
            //如果详情页面中存在数据，则显示新闻的数据
            detailActivity.initWebview();
        }
    }
}
