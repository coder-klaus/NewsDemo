package com.example.eumenides.newsdemo.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ListView;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.adapter.NewsListAdapter;
import com.example.eumenides.newsdemo.bean.Fun;
import com.example.eumenides.newsdemo.bean.FunDetail;
import com.example.eumenides.newsdemo.utils.Constant;
import com.example.eumenides.newsdemo.utils.HttpRespon;
import com.example.eumenides.newsdemo.utils.HttpUtil;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;


/**
 * 这是热点资讯页面（主页中的首页面）
 */

public class HomeFragment extends Fragment {

}

