package com.example.eumenides.newsdemo.controller;


import com.example.eumenides.newsdemo.listener.IModeChangeListener;

public abstract class BaseController {

	protected IModeChangeListener mListener;

	public void setIModeChangeListener(IModeChangeListener listener) {
		mListener=listener;
	}
	

	public void sendAsyncMessage(final int action,final Object... values){
		new Thread(){
			public void run() {
				handleMessage(action, values);
			}
		}.start();
	}


	protected abstract void handleMessage(int action,Object... values);
	

}
