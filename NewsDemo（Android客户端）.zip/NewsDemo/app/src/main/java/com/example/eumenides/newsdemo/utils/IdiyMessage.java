package com.example.eumenides.newsdemo.utils;

/**
 * 这是一个标识类，用来标识所有不同的HTTP请求
 */
public class IdiyMessage {

	//登录
	public static final int LOGIN_ACTION=1;
	public static final int LOGIN_ACTION_RESULT=2;

	//注册
	public static final int REGIST_ACTION=3;
	public static final int REGIST_ACTION_RESULT=4;

	//更新数据
	public static final int UPDATE_ACTION=5;
	public static final int  UPDATE_ACTION_RESULT=6;
}
