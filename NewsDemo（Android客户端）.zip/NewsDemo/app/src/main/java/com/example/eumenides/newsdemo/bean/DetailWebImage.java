package com.example.eumenides.newsdemo.bean;

import java.io.Serializable;

/**
 *  这是新闻详情页面中的图片的javabean类
 */
public class DetailWebImage implements Serializable {

    private String alt;
    private String pixel;
    private String refer;
    private String src;

    public String getAlt() {
        return alt;
    }

    public void setAlt(String alt) {
        this.alt = alt;
    }

    public String getPixel() {
        return pixel;
    }

    public void setPixel(String pixel) {
        this.pixel = pixel;
    }

    public String getRefer() {
        return refer;
    }

    public void setRefer(String refer) {
        this.refer = refer;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }
}
