package com.example.eumenides.newsdemo.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eumenides.newsdemo.R;
import com.example.eumenides.newsdemo.activity.EditMineActivity;
import com.example.eumenides.newsdemo.activity.LoginActivity;
import com.example.eumenides.newsdemo.utils.ApplicationUtil;
import com.example.eumenides.newsdemo.utils.SharedPreUtil;

import java.text.DecimalFormat;


/**
 * 这是设置页面的碎片
 */

public class SettingFragment extends Fragment implements View.OnClickListener {
    private View view;
    private Context context;

    private TextView exit_app, about_app, check_version, welcome_app, clear_cache, edit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_setting, container, false);


        initUI();


        welcome_app.setOnClickListener(this);

        check_version.setOnClickListener(this);

        about_app.setOnClickListener(this);

        clear_cache.setOnClickListener(this);

        edit.setOnClickListener(this);

        welcome_app.setOnClickListener(this);

        exit_app.setOnClickListener(this);


        return view;
    }

    private void initUI() {
        welcome_app = view.findViewById(R.id.welcome_app);
        check_version = view.findViewById(R.id.check_version);
        about_app = view.findViewById(R.id.about_app);
        clear_cache = view.findViewById(R.id.clear_cache);
        edit = view.findViewById(R.id.edit);
        exit_app = view.findViewById(R.id.exit_app);
        context = getContext();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.check_version: { //检查版本
                Toast.makeText(getContext(), "当前的已经是最新的版本", Toast.LENGTH_SHORT).show();
            }
            break;
            case R.id.about_app: {//关于应用
                Toast.makeText(getContext(), "@News version 1.0", Toast.LENGTH_LONG).show();
            }
            break;
            case R.id.clear_cache: { //清空缓存
                float randomnum = (float) (Math.random() * 10);
                //清除本地的SharedPreference的信息
                SharedPreUtil.cleanInternalCache(context);
                Toast.makeText(context, "本次清理" + new DecimalFormat("0.00").format(randomnum) + "M缓存", Toast.LENGTH_SHORT).show();
            }
            break;
            case R.id.edit: { //账号安全
                String username = (String) SharedPreUtil.getParam(getActivity(), SharedPreUtil.LOGIN_DATA, "");
                if (username.isEmpty()) {
                    SharedPreUtil.setParam(getActivity(),SharedPreUtil.CLEAR_CACHE,"clear");

                    Intent intent = new Intent(getContext(), LoginActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getContext(), EditMineActivity.class);
                    startActivity(intent);
                }
            }
            break;
            case R.id.welcome_app: { //注销登录
                //清除用户密码
                SharedPreUtil.removeParam(context, SharedPreUtil.LOGIN_PWD);
                Intent intent = new Intent(getContext(), LoginActivity.class);
                startActivity(intent);
            }
            break;
            case R.id.exit_app: { //退出应用
                //清除用户密码
                SharedPreUtil.removeParam(context, SharedPreUtil.LOGIN_PWD);
                ApplicationUtil.getInstance().exit();
            }
            break;
            default:
                break;

        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }
}
